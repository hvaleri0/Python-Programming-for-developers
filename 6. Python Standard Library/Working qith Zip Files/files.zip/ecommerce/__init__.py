print("Ecommerce Initialized")
